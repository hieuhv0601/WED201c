function openNav(){
    var open = document.getElementById("mySidebar");
    open.style.width = "300px";
}
function closeNav(){
    var open = document.getElementById("mySidebar");
    open.style.width = "0px";
}